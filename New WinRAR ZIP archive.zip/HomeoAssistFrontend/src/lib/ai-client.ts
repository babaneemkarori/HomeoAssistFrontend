import { apiRequest } from "./queryClient";

export interface SymptomAnalysis {
  symptoms: string[];
  repertoryRubrics: string[];
  severity: "mild" | "moderate" | "severe";
  duration: string;
  modalities: {
    worse: string[];
    better: string[];
  };
}

export interface RemedySuggestion {
  remedy: string;
  potency: string;
  dosage: string;
  confidence: number;
  reasoning: string;
  safety: string[];
}

export interface AIAnalysisResult {
  analysis: SymptomAnalysis;
  remedies: RemedySuggestion[];
  warnings: string[];
  followUpQuestions: string[];
}

export class AIClient {
  async analyzeSymptoms(symptoms: string, userId: string, language: string = "en"): Promise<AIAnalysisResult> {
    try {
      const response = await apiRequest("POST", "/api/consultation/analyze", {
        userId,
        symptoms,
        language,
      });
      
      const result = await response.json();
      return result.analysis;
    } catch (error) {
      console.error("AI analysis failed:", error);
      throw new Error("Failed to analyze symptoms. Please try again.");
    }
  }

  async translateText(text: string, targetLanguage: string): Promise<string> {
    try {
      const response = await apiRequest("POST", "/api/translate", {
        text,
        targetLanguage,
      });
      
      const result = await response.json();
      return result.translatedText;
    } catch (error) {
      console.error("Translation failed:", error);
      return text; // Return original text if translation fails
    }
  }

  async processDocument(fileId: string): Promise<{
    success: boolean;
    extractedText?: string;
    analysis?: AIAnalysisResult;
  }> {
    try {
      const response = await apiRequest("GET", `/api/files/${fileId}`);
      const result = await response.json();
      
      if (result.file.processingStatus === "completed" && result.file.extractedText) {
        // If we have extracted text, we can optionally analyze it
        return {
          success: true,
          extractedText: result.file.extractedText,
        };
      }
      
      return { success: false };
    } catch (error) {
      console.error("Document processing failed:", error);
      return { success: false };
    }
  }

  async getConsultationHistory(userId: string): Promise<any[]> {
    try {
      const response = await apiRequest("GET", `/api/consultations/${userId}`);
      const result = await response.json();
      return result.consultations || [];
    } catch (error) {
      console.error("Failed to get consultation history:", error);
      return [];
    }
  }

  formatRemedyDisplay(remedy: RemedySuggestion): string {
    return `
**${remedy.remedy}** (${Math.round(remedy.confidence * 100)}% match)

*Potency:* ${remedy.potency}
*Dosage:* ${remedy.dosage}

*Why this remedy:* ${remedy.reasoning}

${remedy.safety.length > 0 ? `*Safety:* ${remedy.safety.join(", ")}` : ""}
    `.trim();
  }

  formatAnalysisDisplay(analysis: SymptomAnalysis): string {
    return `
**Symptom Analysis:**

*Identified Symptoms:* ${analysis.symptoms.join(", ")}
*Severity:* ${analysis.severity}
*Duration:* ${analysis.duration}

*Modalities:*
- Worse: ${analysis.modalities.worse.join(", ") || "Not specified"}
- Better: ${analysis.modalities.better.join(", ") || "Not specified"}

*Repertory Rubrics:* ${analysis.repertoryRubrics.join(", ")}
    `.trim();
  }
}

export const aiClient = new AIClient();
