import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, BookOpen, Pill, AlertCircle, Filter } from "lucide-react";

interface SearchResult {
  type: "remedy" | "symptom" | "rubric";
  title: string;
  content: string;
  relevance: number;
}

export default function Reference() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSearch, setActiveSearch] = useState("");

  const { data: searchResults, isLoading: searchLoading } = useQuery({
    queryKey: ["/api/reference/search", { q: activeSearch, lang: "en" }],
    enabled: !!activeSearch && !!user,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setActiveSearch(searchQuery.trim());
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Please login to access the reference library</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8 px-4" data-testid="reference-page">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Homeopathy Reference Library</h1>
          <p className="text-muted-foreground">
            Comprehensive database of remedies, materia medica, and repertory
          </p>
        </div>

        {/* Search Bar */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <form onSubmit={handleSearch} className="flex gap-4" data-testid="search-form">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search remedies, symptoms, or conditions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="search-input"
                />
              </div>
              <Button type="submit" data-testid="search-button">
                <Search className="w-4 h-4 mr-2" />
                Search
              </Button>
              <Button variant="outline" data-testid="filter-button">
                <Filter className="w-4 h-4" />
              </Button>
            </form>
          </CardContent>
        </Card>

        <Tabs defaultValue="search" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="search" data-testid="tab-search">Search Results</TabsTrigger>
            <TabsTrigger value="remedies" data-testid="tab-remedies">Remedies A-Z</TabsTrigger>
            <TabsTrigger value="symptoms" data-testid="tab-symptoms">Symptoms</TabsTrigger>
            <TabsTrigger value="tools" data-testid="tab-tools">Tools</TabsTrigger>
          </TabsList>

          <TabsContent value="search" className="mt-6">
            {!activeSearch ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">Start Your Search</h3>
                  <p className="text-muted-foreground">
                    Enter symptoms, remedy names, or conditions to search our comprehensive database
                  </p>
                </CardContent>
              </Card>
            ) : searchLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Card key={i}>
                    <CardContent className="p-6">
                      <div className="animate-pulse space-y-3">
                        <div className="h-4 bg-muted rounded w-1/3"></div>
                        <div className="h-4 bg-muted rounded w-full"></div>
                        <div className="h-4 bg-muted rounded w-2/3"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : searchResults?.length > 0 ? (
              <div className="space-y-4" data-testid="search-results">
                {searchResults.map((result: SearchResult, index: number) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <h3 className="text-lg font-semibold text-foreground">{result.title}</h3>
                        <Badge variant="outline" className="capitalize">
                          {result.type}
                        </Badge>
                      </div>
                      <div className="prose prose-sm max-w-none">
                        <div className="text-muted-foreground whitespace-pre-line">
                          {result.content}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No Results Found</h3>
                  <p className="text-muted-foreground">
                    Try searching for different terms or check your spelling
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="remedies" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Pill className="w-5 h-5" />
                  Remedy Index
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {["Aconitum", "Arnica", "Belladonna", "Bryonia", "Calcarea", "Gelsemium", "Lycopodium", "Natrum Mur", "Nux Vomica", "Pulsatilla", "Rhus Tox", "Sulphur"].map((remedy) => (
                    <Button
                      key={remedy}
                      variant="outline"
                      className="justify-start p-4 h-auto"
                      onClick={() => {
                        setSearchQuery(remedy);
                        setActiveSearch(remedy);
                      }}
                      data-testid={`remedy-${remedy.toLowerCase()}`}
                    >
                      <div className="text-left">
                        <p className="font-semibold">{remedy}</p>
                        <p className="text-xs text-muted-foreground">Click to view details</p>
                      </div>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="symptoms" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Symptom Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold text-foreground mb-3">Physical Symptoms</h3>
                    <div className="space-y-2">
                      {["Headache", "Fever", "Cough", "Digestive Issues", "Joint Pain", "Skin Problems"].map((symptom) => (
                        <Button
                          key={symptom}
                          variant="ghost"
                          className="w-full justify-start"
                          onClick={() => {
                            setSearchQuery(symptom);
                            setActiveSearch(symptom);
                          }}
                          data-testid={`symptom-${symptom.toLowerCase().replace(/\s+/g, '-')}`}
                        >
                          {symptom}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold text-foreground mb-3">Mental/Emotional</h3>
                    <div className="space-y-2">
                      {["Anxiety", "Depression", "Irritability", "Fear", "Grief", "Stress"].map((symptom) => (
                        <Button
                          key={symptom}
                          variant="ghost"
                          className="w-full justify-start"
                          onClick={() => {
                            setSearchQuery(symptom);
                            setActiveSearch(symptom);
                          }}
                          data-testid={`mental-symptom-${symptom.toLowerCase()}`}
                        >
                          {symptom}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tools" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Dosage Calculator</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Input placeholder="Age" type="number" data-testid="dosage-age" />
                    <Input placeholder="Weight (kg)" type="number" data-testid="dosage-weight" />
                    <Input placeholder="Condition type" data-testid="dosage-condition" />
                    <Button className="w-full" data-testid="calculate-dosage">
                      Calculate Dosage
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Remedy Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Input placeholder="First remedy" data-testid="compare-remedy-1" />
                    <Input placeholder="Second remedy" data-testid="compare-remedy-2" />
                    <Button className="w-full" data-testid="compare-remedies">
                      Compare Remedies
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
