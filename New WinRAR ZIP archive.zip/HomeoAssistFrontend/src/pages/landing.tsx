import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import PaymentCards from "@/components/payment-cards";
import LanguageToggle from "@/components/language-toggle";
import { 
  Leaf, 
  Shield, 
  UserCheck, 
  Lock, 
  Play, 
  CheckCircle, 
  Bot, 
  FileImage, 
  BookOpen, 
  TrendingUp, 
  Languages, 
  Heart,
  Menu
} from "lucide-react";

export default function Landing() {
  const scrollToPricing = () => {
    document.getElementById("pricing")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation Header */}
      <nav className="sticky top-0 z-50 bg-card border-b border-border shadow-sm" data-testid="landing-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Leaf className="text-primary text-2xl" />
                <span className="text-xl font-bold text-foreground">HomeoAI</span>
              </div>
              <div className="hidden sm:block">
                <LanguageToggle />
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-6">
              <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors">Features</a>
              <a href="#pricing" className="text-muted-foreground hover:text-foreground transition-colors">Pricing</a>
              <a href="#about" className="text-muted-foreground hover:text-foreground transition-colors">About</a>
              <Link href="/login">
                <Button data-testid="login-button">Login</Button>
              </Link>
            </div>
            
            <Button variant="ghost" className="md:hidden" data-testid="mobile-menu">
              <Menu className="text-xl" />
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="gradient-bg py-20 px-4" data-testid="hero-section">
        <div className="max-w-7xl mx-auto text-center">
          <div className="animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold text-primary-foreground mb-6">
              AI-Powered Homeopathy<br />
              <span className="text-accent">Medical Assistant</span>
            </h1>
            <p className="text-xl md:text-2xl text-primary-foreground/90 mb-8 max-w-3xl mx-auto">
              Get personalized homeopathic remedies, track your health, and access comprehensive medical references with advanced AI assistance
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Button 
                onClick={scrollToPricing}
                className="bg-accent text-accent-foreground px-8 py-4 text-lg font-semibold hover:opacity-90 transition-opacity"
                data-testid="start-trial-button"
              >
                Start Free Trial
              </Button>
              <Button 
                variant="outline"
                className="bg-card text-card-foreground border border-border px-8 py-4 text-lg font-semibold hover:bg-muted transition-colors"
                data-testid="watch-demo-button"
              >
                <Play className="mr-2" />
                Watch Demo
              </Button>
            </div>

            <div className="flex flex-wrap justify-center items-center gap-8 text-primary-foreground/80">
              <div className="flex items-center space-x-2">
                <Shield className="text-secondary" />
                <span>AYUSH Compliant</span>
              </div>
              <div className="flex items-center space-x-2">
                <UserCheck className="text-secondary" />
                <span>Doctor Verified</span>
              </div>
              <div className="flex items-center space-x-2">
                <Lock className="text-secondary" />
                <span>Data Secure</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Subscription Plans Section */}
      <section id="pricing" className="py-20 px-4 bg-muted" data-testid="pricing-section">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Choose Your Plan</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Access comprehensive homeopathic medical assistance with flexible subscription options
            </p>
          </div>
          <PaymentCards />
        </div>
      </section>

      {/* Dashboard Preview Section */}
      <section className="py-20 px-4 bg-background" data-testid="dashboard-preview">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Your AI Medical Dashboard</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experience comprehensive homeopathic healthcare management in one powerful interface
            </p>
          </div>

          <Card className="shadow-lg border border-border">
            <CardContent className="p-6">
              <div className="flex flex-wrap gap-2 mb-6 border-b border-border pb-4">
                <Button className="bg-primary text-primary-foreground">
                  <Bot className="w-4 h-4 mr-2" />
                  AI Assistant
                </Button>
                <Button variant="ghost" className="text-muted-foreground">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  History
                </Button>
                <Button variant="ghost" className="text-muted-foreground">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Reference
                </Button>
                <Button variant="ghost" className="text-muted-foreground">
                  <UserCheck className="w-4 h-4 mr-2" />
                  Profile
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <div className="bg-muted rounded-lg p-4 h-96 overflow-y-auto space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                        <Bot className="text-primary-foreground text-sm" />
                      </div>
                      <Card className="max-w-xs shadow-sm">
                        <CardContent className="p-3">
                          <p className="text-sm">Hello! I'm your AI homeopathy assistant. Please describe your symptoms, and I'll help suggest appropriate remedies.</p>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="flex items-start space-x-3 justify-end">
                      <Card className="bg-primary max-w-xs">
                        <CardContent className="p-3">
                          <p className="text-sm text-primary-foreground">I have been experiencing headaches and fatigue for the past few days. Can you help?</p>
                        </CardContent>
                      </Card>
                      <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                        <UserCheck className="text-secondary-foreground text-sm" />
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                        <Bot className="text-primary-foreground text-sm" />
                      </div>
                      <Card className="max-w-md shadow-sm">
                        <CardContent className="p-4">
                          <p className="text-sm mb-3">Based on your symptoms, here are some homeopathic remedies to consider:</p>
                          <div className="space-y-2">
                            <div className="bg-muted p-2 rounded text-xs">
                              <strong>Bryonia Alba 30C</strong><br />
                              <span className="text-muted-foreground">For headaches with fatigue, especially when worse from motion</span>
                            </div>
                            <div className="bg-muted p-2 rounded text-xs">
                              <strong>Gelsemium 30C</strong><br />
                              <span className="text-muted-foreground">For headaches with mental fatigue and drowsiness</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <Card className="bg-muted">
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-foreground mb-3">Quick Actions</h3>
                      <div className="space-y-2">
                        <Button variant="ghost" className="w-full justify-start text-sm">
                          <BookOpen className="text-primary mr-2" />
                          Search Remedies
                        </Button>
                        <Button variant="ghost" className="w-full justify-start text-sm">
                          <Bot className="text-primary mr-2" />
                          Dosage Calculator
                        </Button>
                        <Button variant="ghost" className="w-full justify-start text-sm">
                          <Heart className="text-accent mr-2" />
                          Emergency Finder
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 bg-muted" data-testid="features-section">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Comprehensive Healthcare Features</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Advanced AI-powered tools for complete homeopathic healthcare management
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="shadow-lg border border-border">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Bot className="text-primary text-xl" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">AI Medical Assistant</h3>
                <p className="text-muted-foreground mb-4">Intelligent analysis of symptoms with personalized homeopathic remedy suggestions based on classical principles.</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Natural language processing</li>
                  <li>• Multi-language support</li>
                  <li>• Voice input capability</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-lg border border-border">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-4">
                  <FileImage className="text-secondary text-xl" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Document Processing</h3>
                <p className="text-muted-foreground mb-4">Advanced OCR and OMR for extracting information from handwritten and printed medical documents.</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Handwriting recognition</li>
                  <li>• Medical form processing</li>
                  <li>• Multi-format support</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-lg border border-border">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <BookOpen className="text-accent text-xl" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Complete Reference</h3>
                <p className="text-muted-foreground mb-4">Comprehensive homeopathic materia medica and repertory database with cross-referencing capabilities.</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Full repertory database</li>
                  <li>• Materia medica texts</li>
                  <li>• Advanced search filters</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-lg border border-border">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="text-primary text-xl" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Health Tracking</h3>
                <p className="text-muted-foreground mb-4">Monitor treatment progress, track symptoms, and maintain detailed health records for the entire family.</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Progress analytics</li>
                  <li>• Family profiles</li>
                  <li>• Symptom timeline</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-lg border border-border">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-4">
                  <Languages className="text-secondary text-xl" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Multi-language Support</h3>
                <p className="text-muted-foreground mb-4">Real-time translation of medical terms and remedies to Hindi and other Indian languages for better understanding.</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Hindi translation</li>
                  <li>• Regional languages</li>
                  <li>• Medical terminology</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-lg border border-border">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <Heart className="text-accent text-xl" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Emergency Tools</h3>
                <p className="text-muted-foreground mb-4">Quick access to emergency remedies, dosage calculator, and safety warnings for urgent situations.</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Emergency finder</li>
                  <li>• Dosage calculator</li>
                  <li>• Safety warnings</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12 px-4" data-testid="footer">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Leaf className="text-primary text-2xl" />
                <span className="text-xl font-bold text-foreground">HomeoAI</span>
              </div>
              <p className="text-muted-foreground">Advanced AI-powered homeopathic medical assistance for comprehensive healthcare management.</p>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-4">Features</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">AI Assistant</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Reference Library</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Health Tracking</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Emergency Tools</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-4">Support</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Contact Us</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-4">Connect</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-border mt-8 pt-8 text-center">
            <p className="text-muted-foreground">
              <strong>Medical Disclaimer:</strong> This app provides educational information only. 
              Always consult qualified healthcare professionals for medical advice. 
              AYUSH Ministry guidelines compliant.
            </p>
            <p className="text-muted-foreground mt-2">
              © 2024 HomeoAI. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
