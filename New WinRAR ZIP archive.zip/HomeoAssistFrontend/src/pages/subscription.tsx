import { useAuth } from "@/hooks/use-auth";
import { useSubscription } from "@/hooks/use-subscription";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import PaymentCards from "@/components/payment-cards";
import { CheckCircle, Clock, AlertCircle, CreditCard, Calendar } from "lucide-react";

export default function Subscription() {
  const { user } = useAuth();
  const { subscription, hasActiveSubscription, isLoading } = useSubscription();

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Please login to view subscription details</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8 px-4" data-testid="subscription-page">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-foreground mb-4">Subscription Management</h1>
          <p className="text-xl text-muted-foreground">
            Manage your HomeoAI subscription and access advanced features
          </p>
        </div>

        {/* Current Subscription Status */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CreditCard className="w-5 h-5" />
              Current Subscription
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-muted rounded w-1/3"></div>
                <div className="h-4 bg-muted rounded w-1/2"></div>
              </div>
            ) : subscription ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <p className="text-sm text-muted-foreground">Plan</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-lg font-semibold text-foreground capitalize" data-testid="current-plan">
                      {subscription.plan}
                    </p>
                    <Badge 
                      variant={subscription.status === "active" ? "default" : "secondary"}
                      data-testid="subscription-status"
                    >
                      {subscription.status}
                    </Badge>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">Amount Paid</p>
                  <p className="text-lg font-semibold text-foreground" data-testid="amount-paid">
                    ₹{subscription.amount}
                  </p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">
                    {subscription.plan === "lifetime" ? "Valid" : "Expires"}
                  </p>
                  <div className="flex items-center space-x-2">
                    {subscription.status === "active" ? (
                      <CheckCircle className="w-4 h-4 text-secondary" />
                    ) : (
                      <Clock className="w-4 h-4 text-muted-foreground" />
                    )}
                    <p className="text-lg font-semibold text-foreground" data-testid="subscription-expiry">
                      {subscription.plan === "lifetime" 
                        ? "Forever" 
                        : subscription.expiresAt 
                          ? new Date(subscription.expiresAt).toLocaleDateString()
                          : "N/A"
                      }
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No active subscription</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Subscribe to unlock all features and AI consultations
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Features by Plan */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle>What's Included in Your Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="space-y-3">
                <h3 className="font-semibold text-foreground">Basic Features</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-secondary" />
                    <span>AI Symptom Analysis</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-secondary" />
                    <span>Remedy Database Access</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-secondary" />
                    <span>Basic Health Tracking</span>
                  </li>
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold text-foreground">Advanced Features</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className={`w-4 h-4 ${hasActiveSubscription ? 'text-secondary' : 'text-muted-foreground'}`} />
                    <span className={hasActiveSubscription ? '' : 'text-muted-foreground'}>
                      Voice Input & OCR
                    </span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className={`w-4 h-4 ${hasActiveSubscription ? 'text-secondary' : 'text-muted-foreground'}`} />
                    <span className={hasActiveSubscription ? '' : 'text-muted-foreground'}>
                      Multi-language Support
                    </span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className={`w-4 h-4 ${hasActiveSubscription ? 'text-secondary' : 'text-muted-foreground'}`} />
                    <span className={hasActiveSubscription ? '' : 'text-muted-foreground'}>
                      Family Health Profiles
                    </span>
                  </li>
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold text-foreground">Premium Features</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className={`w-4 h-4 ${subscription?.plan === 'yearly' || subscription?.plan === 'lifetime' ? 'text-secondary' : 'text-muted-foreground'}`} />
                    <span className={subscription?.plan === 'yearly' || subscription?.plan === 'lifetime' ? '' : 'text-muted-foreground'}>
                      Priority AI Responses
                    </span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className={`w-4 h-4 ${subscription?.plan === 'yearly' || subscription?.plan === 'lifetime' ? 'text-secondary' : 'text-muted-foreground'}`} />
                    <span className={subscription?.plan === 'yearly' || subscription?.plan === 'lifetime' ? '' : 'text-muted-foreground'}>
                      Advanced Analytics
                    </span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className={`w-4 h-4 ${subscription?.plan === 'lifetime' ? 'text-secondary' : 'text-muted-foreground'}`} />
                    <span className={subscription?.plan === 'lifetime' ? '' : 'text-muted-foreground'}>
                      Commercial Usage Rights
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscription Plans */}
        {!hasActiveSubscription && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-2">Choose Your Plan</h2>
              <p className="text-muted-foreground">
                Select the subscription that best fits your healthcare needs
              </p>
            </div>
            <PaymentCards />
          </div>
        )}

        {/* Billing History */}
        {subscription && (
          <Card className="mt-12">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="w-5 h-5" />
                Billing History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground capitalize">{subscription.plan} Plan</p>
                      <p className="text-sm text-muted-foreground">
                        Payment ID: {subscription.paymentId}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-foreground">₹{subscription.amount}</p>
                    <p className="text-sm text-muted-foreground">
                      {subscription.createdAt ? new Date(subscription.createdAt).toLocaleDateString() : "Recently"}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
