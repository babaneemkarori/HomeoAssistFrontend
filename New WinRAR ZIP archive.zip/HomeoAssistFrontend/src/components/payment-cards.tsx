import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, CreditCard, Smartphone } from "lucide-react";
import { useSubscription } from "@/hooks/use-subscription";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const plans = [
  {
    name: "Monthly",
    price: 199,
    duration: "/month",
    description: "Perfect for trying out",
    features: [
      "Unlimited AI consultations",
      "Complete remedy database",
      "Voice input & OCR",
      "Multi-language support",
      "Health tracking",
    ],
    planCode: "monthly",
    popular: false,
  },
  {
    name: "Yearly",
    price: 1200,
    duration: "/year",
    description: "Save 50%! (₹100/month)",
    features: [
      "Everything in Monthly",
      "Priority AI responses",
      "Advanced analytics",
      "Family profiles (up to 5)",
      "Export reports (PDF)",
    ],
    planCode: "yearly",
    popular: true,
  },
  {
    name: "Lifetime",
    price: 3000,
    duration: "one-time",
    description: "Best Value Forever!",
    features: [
      "Everything in Yearly",
      "Lifetime updates",
      "Premium support",
      "Unlimited family profiles",
      "Commercial usage rights",
    ],
    planCode: "lifetime",
    popular: false,
  },
];

export default function PaymentCards() {
  const { user } = useAuth();
  const { createOrder, verifyPayment, upiPayment, isCreatingOrder, isVerifyingPayment, isProcessingUPI } = useSubscription();
  const { toast } = useToast();

  const handleRazorpayPayment = async (amount: number, plan: string) => {
    if (!user) {
      toast({
        title: "Login required",
        description: "Please login to subscribe",
        variant: "destructive",
      });
      return;
    }

    try {
      const order = await createOrder({ amount, plan });
      
      // Initialize Razorpay checkout
      const options = {
        key: import.meta.env.VITE_RAZORPAY_KEY_ID || "rzp_test_key",
        amount: order.order.amount,
        currency: "INR",
        name: "HomeoAI",
        description: `${plan} subscription`,
        order_id: order.order.id,
        handler: async function (response: any) {
          try {
            await verifyPayment({
              paymentId: response.razorpay_payment_id,
              orderId: response.razorpay_order_id,
              signature: response.razorpay_signature,
              plan,
              amount,
            });
          } catch (error) {
            console.error("Payment verification failed:", error);
          }
        },
        prefill: {
          email: user.email,
          name: user.name,
        },
        theme: {
          color: "#3B9EE0",
        },
      };

      // For demo purposes, simulate successful payment
      setTimeout(async () => {
        await verifyPayment({
          paymentId: `pay_${Date.now()}`,
          orderId: order.order.id,
          signature: `sig_${Date.now()}`,
          plan,
          amount,
        });
      }, 1000);
    } catch (error) {
      toast({
        title: "Payment failed",
        description: "Unable to process payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleUPIPayment = async (amount: number, plan: string) => {
    if (!user) {
      toast({
        title: "Login required",
        description: "Please login to subscribe",
        variant: "destructive",
      });
      return;
    }

    try {
      await upiPayment({ amount, plan });
    } catch (error) {
      toast({
        title: "UPI payment failed",
        description: "Please try again or use Razorpay.",
        variant: "destructive",
      });
    }
  };

  const generateUPILink = (amount: number) => {
    return `upi://pay?pa=pandeykamalakar@ybl&pn=Kamalakar%20Pandey&am=${amount}&cu=INR`;
  };

  if (!user) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground mb-4">Please login to view subscription plans</p>
        <Link href="/login">
          <Button>Login to Continue</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto" data-testid="payment-cards">
      {plans.map((plan) => (
        <Card
          key={plan.planCode}
          className={`subscription-card shadow-lg ${
            plan.popular ? "border-2 border-primary relative" : "border border-border"
          }`}
          data-testid={`plan-card-${plan.planCode}`}
        >
          {plan.popular && (
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <span className="bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                Most Popular
              </span>
            </div>
          )}

          <CardContent className="p-8">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-foreground mb-2">{plan.name}</h3>
              <div className="flex items-center justify-center space-x-2">
                <span className="text-4xl font-bold text-primary">₹{plan.price}</span>
                <span className="text-muted-foreground">{plan.duration}</span>
              </div>
              <p className={`mt-2 font-semibold ${plan.popular ? "text-secondary" : "text-muted-foreground"}`}>
                {plan.description}
              </p>
            </div>

            <ul className="space-y-4 mb-8">
              {plan.features.map((feature, index) => (
                <li key={index} className="flex items-center space-x-3">
                  <CheckCircle className="text-secondary w-5 h-5" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>

            <div className="space-y-3">
              <Button
                onClick={() => handleRazorpayPayment(plan.price, plan.planCode)}
                disabled={isCreatingOrder || isVerifyingPayment}
                className="w-full bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
                data-testid={`razorpay-button-${plan.planCode}`}
              >
                <CreditCard className="mr-2 w-4 h-4" />
                {isCreatingOrder || isVerifyingPayment ? "Processing..." : "Pay with Razorpay"}
              </Button>

              <a
                href={generateUPILink(plan.price)}
                className="w-full bg-secondary text-secondary-foreground py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity flex items-center justify-center"
                data-testid={`upi-link-${plan.planCode}`}
              >
                <Smartphone className="mr-2 w-4 h-4" />
                Pay with UPI
              </a>

              <Button
                onClick={() => handleUPIPayment(plan.price, plan.planCode)}
                disabled={isProcessingUPI}
                variant="outline"
                className="w-full"
                data-testid={`upi-button-${plan.planCode}`}
              >
                {isProcessingUPI ? "Processing..." : "Simulate UPI Payment"}
              </Button>

              <div className="text-center pt-2">
                <p className="text-sm text-muted-foreground mb-2">Or scan QR code</p>
                <div className="inline-block p-3 bg-background rounded-lg">
                  <div className="w-32 h-32 bg-muted rounded border-2 border-dashed border-border flex items-center justify-center text-muted-foreground text-sm">
                    QR Code<br />₹{plan.price}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
